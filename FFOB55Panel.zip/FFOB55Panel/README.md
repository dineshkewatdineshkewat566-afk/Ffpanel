# FF OB55 Aim Headshot Panel

Offline floating aim-training panel (Android 10+, Kotlin, no dependencies, no root).

The panel is a self-contained practice arena. It does NOT read, inject into, or modify
Free Fire (or any app): no memory access, no anti-cheat bypass, no auto-aim/auto-fire,
no aim/recoil/sensitivity/hit-detection changes. It works with Free Fire OB55 (or any
other app) only in the sense that it floats on top of it.

## Project layout
```
FFOB55Panel/
  settings.gradle.kts, build.gradle.kts, gradle.properties
  gradle/wrapper/gradle-wrapper.properties
  .github/workflows/build.yml          (optional: build the APK in the cloud)
  app/build.gradle.kts, proguard-rules.pro
  app/src/main/AndroidManifest.xml
  app/src/main/java/com/example/ffob55panel/
      MainActivity.kt     launcher screen: permission, start, stop, reset
      FloatingService.kt  foreground service + draggable overlay panel
      TrainingView.kt     AIM and HEADSHOT practice arena
      Stats.kt            offline statistics (SharedPreferences)
  app/src/main/res/       layout, drawables, colors, themes, icon
```

## Build (Android Studio, recommended)
1. Install Android Studio (Koala or newer; JDK 17 is bundled).
2. File > Open > select the FFOB55Panel folder. Accept "Trust project".
3. Wait for Gradle sync (needs internet once, to download Gradle 8.7 and the Android plugin).
   If Studio asks to install SDK Platform 34, accept.
4. Run on a device/emulator (Run > Run 'app'), or build an APK:
   Build > Build Bundle(s) / APK(s) > Build APK(s).
   Output: app/build/outputs/apk/debug/app-debug.apk

Command line (with Gradle 8.7+ and JDK 17 installed): `gradle assembleDebug`
(or `./gradlew assembleDebug` after running `gradle wrapper` once).

## Build with no PC (phone only)
1. Create a free GitHub account, create a new repository, upload the whole project
   (including the hidden .github folder) using the web uploader.
2. Open the repository > Actions > "Build APK" > Run workflow.
3. When it finishes, download the artifact "FFOB55Panel-debug-apk" (a zip containing
   app-debug.apk), extract it on the phone, and install it.

AIDE note: AIDE does not reliably support Kotlin 1.9 / Gradle Kotlin DSL / AGP 8.
Use Android Studio or the GitHub Actions route above.

## Install on the phone
1. Copy/download app-debug.apk to the phone and tap it.
2. Allow "Install unknown apps" for your file manager/browser when prompted.
3. If Play Protect warns about an unrecognised developer app, choose "Install anyway"
   (the app is self-signed with the debug key).

## First run
1. Open the app, tap "1. Grant overlay permission", enable "Allow display over other
   apps" for this app, press Back.
2. Tap "2. Start floating panel". A notification appears and the panel floats on screen.
3. Open Free Fire (or any app). Drag the panel by its title bar; "-" minimizes to the
   title bar, "+" expands; the X closes the panel; the notification's Stop button also stops it.

## Using the panel
- AIM: drag in the arena to move the crosshair, release to fire at the moving target.
  Feedback shows reaction time, miss distance and the direction to correct.
  Stats: accuracy, average and best reaction time.
- HEADSHOT: an enemy strafes; the crosshair starts on the chest. Drag up to the head
  and release. Feedback: HEADSHOT / BODY / MISS with correction hint. Stats: headshot
  rate, body, miss, current and best streak.
- The reset button clears saved statistics. Everything is stored locally; no internet.

## Troubleshooting
- Panel does not appear: Settings > Apps > FF OB55 Aim Headshot Panel > "Display over
  other apps" must be ON. Some phones (Xiaomi/MIUI, Oppo, Vivo, Huawei) also need
  "Display pop-up windows while running in background" / auto-start allowed and
  battery optimization set to "No restrictions".
- Panel disappears after a while: the OEM killed the service. Disable battery
  optimization for the app and lock it in the recent-apps list.
- No notification on Android 13+: allow notifications for the app (the panel still works).
- "Install blocked": allow installs from unknown sources for the app you used to open the APK.
- Touches on the panel work but the game below does not react: expected; only the
  panel area captures touches, everything outside it goes to the game.
- Gradle sync fails: check internet, use JDK 17 (File > Settings > Build Tools > Gradle >
  Gradle JDK), then File > Invalidate Caches / Restart.
- "SDK location not found": let Studio create local.properties, or install SDK Platform 34
  in SDK Manager.
- Panel too large/small in landscape: change the 290 (width) and 190 (arena height)
  dp values in FloatingService.kt.
