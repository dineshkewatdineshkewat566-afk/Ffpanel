package com.example.ffob55panel

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        val btnPermission = findViewById<Button>(R.id.btnPermission)
        val btnStart = findViewById<Button>(R.id.btnStart)
        val btnStop = findViewById<Button>(R.id.btnStop)
        val btnReset = findViewById<Button>(R.id.btnReset)

        // Android 13+: allow the "panel running" notification to be shown.
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        btnPermission.setOnClickListener { openOverlaySettings() }

        btnStart.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Grant the overlay permission first", Toast.LENGTH_LONG).show()
                openOverlaySettings()
            } else {
                startForegroundService(
                    Intent(this, FloatingService::class.java).setAction(FloatingService.ACTION_START)
                )
                Toast.makeText(this, "Panel started. Switch to your game.", Toast.LENGTH_SHORT).show()
                statusText.postDelayed({ refresh() }, 500)
            }
        }

        btnStop.setOnClickListener {
            stopService(Intent(this, FloatingService::class.java))
            statusText.postDelayed({ refresh() }, 300)
        }

        btnReset.setOnClickListener {
            Stats(this).clear()
            Toast.makeText(this, "Statistics reset", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun openOverlaySettings() {
        startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
        )
    }

    private fun refresh() {
        val granted = Settings.canDrawOverlays(this)
        val running = FloatingService.isRunning
        statusText.text = "Overlay permission:  " + (if (granted) "GRANTED" else "NOT GRANTED") +
            "\nFloating panel:  " + (if (running) "RUNNING" else "STOPPED") +
            "\nMode:  offline"
    }
}
