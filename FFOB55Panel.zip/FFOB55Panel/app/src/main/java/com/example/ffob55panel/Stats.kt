package com.example.ffob55panel

import android.content.Context

/** Tiny offline statistics store (SharedPreferences). Nothing leaves the device. */
class Stats(context: Context) {

    private val sp = context.applicationContext
        .getSharedPreferences("ff_trainer_stats", Context.MODE_PRIVATE)

    fun get(key: String): Int = sp.getInt(key, 0)

    fun add(key: String, n: Int = 1) {
        sp.edit().putInt(key, get(key) + n).apply()
    }

    fun put(key: String, value: Int) {
        sp.edit().putInt(key, value).apply()
    }

    fun clear() {
        sp.edit().clear().apply()
    }

    companion object {
        const val AIM_SHOTS = "aim_shots"
        const val AIM_HITS = "aim_hits"
        const val AIM_TOTAL_MS = "aim_total_ms"
        const val AIM_BEST_MS = "aim_best_ms"
        const val HS_SHOTS = "hs_shots"
        const val HS_HEAD = "hs_head"
        const val HS_BODY = "hs_body"
        const val HS_BEST_STREAK = "hs_best_streak"
    }
}
