package com.example.ffob55panel

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import java.util.Random
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/**
 * Self-contained practice arena drawn inside the floating panel.
 *
 * AIM      - drag to move the crosshair, release to fire at a moving target.
 * HEADSHOT - an enemy strafes; the crosshair starts on its chest, drag up to the
 *            head and release (drag-headshot practice).
 *
 * This view never reads or touches any other app. Everything is simulated here.
 */
class TrainingView(context: Context, private val stats: Stats) : View(context) {

    enum class Mode { AIM, HEADSHOT }

    var onStatsChanged: (() -> Unit)? = null

    var mode: Mode = Mode.AIM
        set(value) {
            field = value
            feedback = ""
            locked = false
            newRound()
            invalidate()
            onStatsChanged?.invoke()
        }

    private val d = resources.displayMetrics.density
    private val rnd = Random()

    // ---- colours ----
    private val cBg = Color.parseColor("#0B0B12")
    private val cGrid = Color.parseColor("#171722")
    private val cAccent = Color.parseColor("#FF4D2E")
    private val cGreen = Color.parseColor("#3DDC84")
    private val cRed = Color.parseColor("#FF5252")
    private val cText = Color.parseColor("#F2F2F7")
    private val cMuted = Color.parseColor("#7C7C8C")

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    // ---- shared state ----
    private var crossX = 0f
    private var crossY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var touching = false
    private var feedback = ""
    private var feedbackColor = cText

    // ---- AIM state ----
    private val targetR = 15f * d
    private var tx = 0f
    private var ty = 0f
    private var tvx = 0f
    private var tvy = 0f
    private var spawnAt = 0L

    // ---- HEADSHOT state ----
    private val headR = 9f * d
    private val bodyW = 26f * d
    private val bodyH = 36f * d
    private val neck = 2f * d
    private var fx = 0f          // enemy centre x
    private var fy = 0f          // enemy feet y
    private var fdir = 1f
    private val fSpeed = 26f * d
    private var locked = false
    private var lockUntil = 0L
    private var result = 0       // 1 = head, 2 = body, 3 = miss
    private var streak = 0

    // ---- animation loop ----
    private var running = false
    private var lastFrame = 0L
    private val frame = object : Runnable {
        override fun run() {
            if (!running) return
            val now = SystemClock.uptimeMillis()
            val dt = (now - lastFrame).coerceAtMost(50L) / 1000f
            lastFrame = now
            update(dt)
            invalidate()
            postOnAnimation(this)
        }
    }

    private fun startLoop() {
        if (running) return
        running = true
        lastFrame = SystemClock.uptimeMillis()
        postOnAnimation(frame)
    }

    private fun stopLoop() {
        running = false
        removeCallbacks(frame)
    }

    // Runs only while the view is really visible (stops when the panel is minimized).
    override fun onVisibilityAggregated(isVisible: Boolean) {
        super.onVisibilityAggregated(isVisible)
        if (isVisible) startLoop() else stopLoop()
    }

    override fun onDetachedFromWindow() {
        stopLoop()
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        newRound()
    }

    // ---------------------------------------------------------------- rounds

    private fun newRound() {
        if (width == 0 || height == 0) return
        locked = false
        if (mode == Mode.AIM) {
            crossX = width / 2f
            crossY = height / 2f
            spawnTarget()
        } else {
            spawnEnemy()
        }
    }

    private fun spawnTarget() {
        val m = targetR + 8f * d
        tx = m + rnd.nextFloat() * (width - 2 * m)
        ty = m + rnd.nextFloat() * (height - 2 * m)
        val a = rnd.nextFloat() * 6.2831855f
        val s = 24f * d
        tvx = cos(a) * s
        tvy = sin(a) * s
        spawnAt = SystemClock.elapsedRealtime()
    }

    private fun spawnEnemy() {
        val total = headR * 2 + neck + bodyH
        val margin = 10f * d
        val minX = bodyW
        val maxX = width - bodyW
        fx = minX + rnd.nextFloat() * (maxX - minX)
        val minFeet = margin + total
        val maxFeet = height - margin
        fy = if (maxFeet > minFeet) minFeet + rnd.nextFloat() * (maxFeet - minFeet) else maxFeet
        fdir = if (rnd.nextBoolean()) 1f else -1f
        crossX = fx
        crossY = fy - bodyH / 2f      // start on the chest
        result = 0
    }

    private fun headCenterY() = fy - bodyH - neck - headR

    // ---------------------------------------------------------------- update

    private fun update(dt: Float) {
        if (width == 0 || height == 0) return
        if (mode == Mode.AIM) {
            val m = targetR + 4f * d
            tx += tvx * dt
            ty += tvy * dt
            if (tx < m) { tx = m; tvx = abs(tvx) }
            if (tx > width - m) { tx = width - m; tvx = -abs(tvx) }
            if (ty < m) { ty = m; tvy = abs(tvy) }
            if (ty > height - m) { ty = height - m; tvy = -abs(tvy) }
        } else {
            if (locked) {
                if (SystemClock.uptimeMillis() >= lockUntil) newRound()
            } else {
                fx += fdir * fSpeed * dt
                val lo = bodyW / 2f + 4f * d
                val hi = width - lo
                if (fx < lo) { fx = lo; fdir = 1f }
                if (fx > hi) { fx = hi; fdir = -1f }
            }
        }
    }

    // ----------------------------------------------------------------- input

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (locked) return true
                touching = true
                lastX = e.x
                lastY = e.y
            }
            MotionEvent.ACTION_MOVE -> if (touching) {
                crossX = (crossX + (e.x - lastX)).coerceIn(0f, width.toFloat())
                crossY = (crossY + (e.y - lastY)).coerceIn(0f, height.toFloat())
                lastX = e.x
                lastY = e.y
            }
            MotionEvent.ACTION_UP -> if (touching) {
                touching = false
                if (mode == Mode.AIM) fireAim() else fireHeadshot()
            }
            MotionEvent.ACTION_CANCEL -> touching = false
        }
        return true
    }

    // ---------------------------------------------------------------- firing

    private fun fireAim() {
        stats.add(Stats.AIM_SHOTS)
        val dist = hypot(crossX - tx, crossY - ty)
        if (dist <= targetR) {
            val ms = (SystemClock.elapsedRealtime() - spawnAt).toInt()
            stats.add(Stats.AIM_HITS)
            stats.add(Stats.AIM_TOTAL_MS, ms)
            val best = stats.get(Stats.AIM_BEST_MS)
            if (best == 0 || ms < best) stats.put(Stats.AIM_BEST_MS, ms)
            feedback = "HIT  ${ms} ms"
            feedbackColor = cGreen
            spawnTarget()
        } else {
            val dx = tx - crossX
            val dy = ty - crossY
            val dir = if (abs(dx) > abs(dy)) {
                if (dx > 0) "right" else "left"
            } else {
                if (dy > 0) "down" else "up"
            }
            feedback = "MISS  ${(dist / d).toInt()} dp off - aim $dir"
            feedbackColor = cRed
        }
        onStatsChanged?.invoke()
    }

    private fun fireHeadshot() {
        stats.add(Stats.HS_SHOTS)
        val headDist = hypot(crossX - fx, crossY - headCenterY())
        val inBody = crossX in (fx - bodyW / 2f - 2f * d)..(fx + bodyW / 2f + 2f * d) &&
            crossY in (fy - bodyH)..fy
        when {
            headDist <= headR * 1.15f -> {
                result = 1
                streak++
                stats.add(Stats.HS_HEAD)
                if (streak > stats.get(Stats.HS_BEST_STREAK)) stats.put(Stats.HS_BEST_STREAK, streak)
                feedback = "HEADSHOT!  streak $streak"
                feedbackColor = cGreen
            }
            inBody -> {
                result = 2
                streak = 0
                stats.add(Stats.HS_BODY)
                feedback = "BODY - drag higher"
                feedbackColor = cAccent
            }
            else -> {
                result = 3
                streak = 0
                val dx = fx - crossX
                val dy = headCenterY() - crossY
                val hint = if (abs(dx) > abs(dy)) (if (dx > 0) "right" else "left")
                else (if (dy > 0) "down" else "up")
                feedback = "MISS - head was $hint"
                feedbackColor = cRed
            }
        }
        locked = true
        lockUntil = SystemClock.uptimeMillis() + 700L
        onStatsChanged?.invoke()
    }

    // ------------------------------------------------------------------ stats

    fun summary(): String {
        return if (mode == Mode.AIM) {
            val shots = stats.get(Stats.AIM_SHOTS)
            val hits = stats.get(Stats.AIM_HITS)
            val acc = if (shots > 0) hits * 100 / shots else 0
            val avg = if (hits > 0) "${stats.get(Stats.AIM_TOTAL_MS) / hits}ms" else "-"
            val best = stats.get(Stats.AIM_BEST_MS).let { if (it > 0) "${it}ms" else "-" }
            "Accuracy $acc% ($hits/$shots)   Avg $avg   Best $best"
        } else {
            val shots = stats.get(Stats.HS_SHOTS)
            val head = stats.get(Stats.HS_HEAD)
            val body = stats.get(Stats.HS_BODY)
            val miss = shots - head - body
            val rate = if (shots > 0) head * 100 / shots else 0
            "Headshot $rate% ($head/$shots)   Body $body   Miss $miss\n" +
                "Streak $streak   Best ${stats.get(Stats.HS_BEST_STREAK)}"
        }
    }

    fun resetStats() {
        stats.clear()
        streak = 0
        feedback = ""
        onStatsChanged?.invoke()
        invalidate()
    }

    // ------------------------------------------------------------------- draw

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        c.drawColor(cBg)

        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f
        p.color = cGrid
        var g = 0f
        while (g < w) { c.drawLine(g, 0f, g, h, p); g += 24f * d }
        g = 0f
        while (g < h) { c.drawLine(0f, g, w, g, p); g += 24f * d }

        val overTarget: Boolean
        if (mode == Mode.AIM) {
            overTarget = hypot(crossX - tx, crossY - ty) <= targetR
            drawTarget(c)
        } else {
            overTarget = !locked && hypot(crossX - fx, crossY - headCenterY()) <= headR * 1.15f
            drawEnemy(c)
        }
        drawCrosshair(c, overTarget)

        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.CENTER
        p.textSize = 11f * d
        if (feedback.isNotEmpty()) {
            p.color = feedbackColor
            c.drawText(feedback, w / 2f, 15f * d, p)
        } else {
            p.color = cMuted
            val hint = if (mode == Mode.AIM) "Drag to aim, release to fire"
            else "Drag from chest to head, release to fire"
            c.drawText(hint, w / 2f, 15f * d, p)
        }
    }

    private fun drawTarget(c: Canvas) {
        p.style = Paint.Style.FILL
        p.color = cAccent
        c.drawCircle(tx, ty, targetR, p)
        p.color = Color.WHITE
        c.drawCircle(tx, ty, targetR * 0.62f, p)
        p.color = cAccent
        c.drawCircle(tx, ty, targetR * 0.28f, p)
    }

    private fun drawEnemy(c: Canvas) {
        p.style = Paint.Style.FILL
        p.color = if (locked && result == 2) cAccent else Color.parseColor("#5E5E70")
        c.drawRoundRect(fx - bodyW / 2f, fy - bodyH, fx + bodyW / 2f, fy, 6f * d, 6f * d, p)
        p.color = if (locked && result == 1) cGreen else Color.parseColor("#C9C9D4")
        c.drawCircle(fx, headCenterY(), headR, p)
    }

    private fun drawCrosshair(c: Canvas, on: Boolean) {
        val col = if (on) cGreen else Color.WHITE
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.6f * d
        p.color = col
        val r = 8f * d
        c.drawCircle(crossX, crossY, r, p)
        c.drawLine(crossX - r - 5f * d, crossY, crossX - r + 3f * d, crossY, p)
        c.drawLine(crossX + r - 3f * d, crossY, crossX + r + 5f * d, crossY, p)
        c.drawLine(crossX, crossY - r - 5f * d, crossX, crossY - r + 3f * d, p)
        c.drawLine(crossX, crossY + r - 3f * d, crossX, crossY + r + 5f * d, p)
        p.style = Paint.Style.FILL
        c.drawCircle(crossX, crossY, 1.5f * d, p)
    }
}
