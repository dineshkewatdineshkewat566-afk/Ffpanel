package com.example.ffob55panel

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Foreground service that owns the floating training panel.
 * Uses TYPE_APPLICATION_OVERLAY (required on Android 8+, therefore on Android 10+).
 */
class FloatingService : Service() {

    companion object {
        const val ACTION_START = "com.example.ffob55panel.START"
        const val ACTION_STOP = "com.example.ffob55panel.STOP"
        private const val CHANNEL_ID = "ff_panel_channel"
        private const val NOTIF_ID = 1001

        @Volatile
        var isRunning = false
            private set
    }

    private lateinit var wm: WindowManager
    private var root: LinearLayout? = null
    private var params: WindowManager.LayoutParams? = null
    private var minimized = false
    private val density get() = resources.displayMetrics.density
    private fun dp(v: Int) = (v * density).toInt()

    private val cAccent = Color.parseColor("#FF4D2E")

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            shutdown()
            return START_NOT_STICKY
        }

        // Must be called within 5 s of startForegroundService().
        startAsForeground()

        if (!Settings.canDrawOverlays(this)) {
            shutdown()
            return START_NOT_STICKY
        }
        if (root == null) addPanel()
        isRunning = true
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        removePanel()
        isRunning = false
        super.onDestroy()
    }

    // ------------------------------------------------------------ foreground

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Floating panel", NotificationManager.IMPORTANCE_LOW)
        )

        val openPi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopPi = PendingIntent.getService(
            this, 1, Intent(this, FloatingService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopAction = Notification.Action.Builder(
            Icon.createWithResource(this, R.drawable.ic_crosshair), "Stop", stopPi
        ).build()

        val n = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_crosshair)
            .setContentTitle("FF OB55 Aim Headshot Panel")
            .setContentText("Training panel is running")
            .setContentIntent(openPi)
            .setOngoing(true)
            .addAction(stopAction)
            .build()

        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    private fun shutdown() {
        removePanel()
        isRunning = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    // ----------------------------------------------------------------- panel

    private fun screenSize(): Pair<Int, Int> {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION")
            wm.defaultDisplay.getRealMetrics(dm)
            dm.widthPixels to dm.heightPixels
        }
    }

    private fun roundBg(color: Int, radiusDp: Int, strokeColor: Int? = null): GradientDrawable {
        return GradientDrawable().apply {
            setColor(color)
            cornerRadius = dp(radiusDp).toFloat()
            if (strokeColor != null) setStroke(dp(1), strokeColor)
        }
    }

    private fun styleTab(t: TextView, selected: Boolean) {
        t.background = roundBg(if (selected) cAccent else Color.parseColor("#22222E"), 8)
        t.setTextColor(if (selected) Color.WHITE else Color.parseColor("#9A9AAA"))
    }

    private fun makeButton(label: String, size: Float = 16f): TextView {
        return TextView(this).apply {
            text = label
            textSize = size
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(4), dp(12), dp(4))
        }
    }

    private fun addPanel() {
        val stats = Stats(this)

        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundBg(Color.parseColor("#F2101018"), 12, cAccent)
        }

        // ---- header (drag handle + minimize + close) ----
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(10), dp(4), dp(4), dp(4))
        }
        val title = TextView(this).apply {
            text = "FF OB55  \u2022  TRAINER"
            textSize = 12f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val btnMin = makeButton("\u2013")
        val btnClose = makeButton("\u2715", 14f)
        header.addView(title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        header.addView(btnMin)
        header.addView(btnClose)
        panel.addView(header)

        // ---- body ----
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(8), 0, dp(8), dp(8))
        }

        val tabRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val tabAim = TextView(this).apply {
            text = "AIM"; textSize = 12f; gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, dp(6), 0, dp(6))
        }
        val tabHs = TextView(this).apply {
            text = "HEADSHOT"; textSize = 12f; gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding(0, dp(6), 0, dp(6))
        }
        val btnReset = makeButton("\u21BA", 14f)
        tabRow.addView(tabAim, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        tabRow.addView(
            tabHs,
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                leftMargin = dp(6)
            }
        )
        tabRow.addView(btnReset)
        body.addView(tabRow)

        val train = TrainingView(this, stats)
        body.addView(
            train,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(190)).apply {
                topMargin = dp(8)
            }
        )

        val statsText = TextView(this).apply {
            textSize = 10.5f
            setTextColor(Color.parseColor("#B8B8C6"))
            setPadding(dp(2), dp(6), dp(2), 0)
        }
        body.addView(statsText)
        panel.addView(body)

        train.onStatsChanged = { statsText.text = train.summary() }

        fun selectTab(m: TrainingView.Mode) {
            styleTab(tabAim, m == TrainingView.Mode.AIM)
            styleTab(tabHs, m == TrainingView.Mode.HEADSHOT)
            train.mode = m
        }
        tabAim.setOnClickListener { selectTab(TrainingView.Mode.AIM) }
        tabHs.setOnClickListener { selectTab(TrainingView.Mode.HEADSHOT) }
        selectTab(TrainingView.Mode.AIM)

        btnReset.setOnClickListener { train.resetStats() }

        btnMin.setOnClickListener {
            minimized = !minimized
            body.visibility = if (minimized) View.GONE else View.VISIBLE
            btnMin.text = if (minimized) "+" else "\u2013"
        }
        btnClose.setOnClickListener { shutdown() }

        // ---- window params ----
        val lp = WindowManager.LayoutParams(
            dp(290),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(24)
            y = dp(24)
        }

        // ---- drag by header ----
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        header.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = e.rawX; touchY = e.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val (sw, sh) = screenSize()
                    lp.x = (startX + (e.rawX - touchX).toInt())
                        .coerceIn(0, (sw - panel.width).coerceAtLeast(0))
                    lp.y = (startY + (e.rawY - touchY).toInt())
                        .coerceIn(0, (sh - panel.height).coerceAtLeast(0))
                    wm.updateViewLayout(panel, lp)
                    true
                }
                else -> true
            }
        }

        wm.addView(panel, lp)
        root = panel
        params = lp
    }

    private fun removePanel() {
        root?.let {
            try {
                wm.removeView(it)
            } catch (_: IllegalArgumentException) {
                // already removed
            }
        }
        root = null
        params = null
    }
}
